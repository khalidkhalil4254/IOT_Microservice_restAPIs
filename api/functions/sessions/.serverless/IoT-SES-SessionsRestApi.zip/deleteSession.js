const res = require('./common/responses');
const config = require('./common/config');
const mysql = require('mysql');

module.exports.handler=async(event, context, callback)=>{
    
}